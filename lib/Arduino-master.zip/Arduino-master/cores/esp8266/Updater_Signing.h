// This file will be overridden when automatic signing is used.
// By default, no signing.
#define ARDUINO_SIGNING 0
